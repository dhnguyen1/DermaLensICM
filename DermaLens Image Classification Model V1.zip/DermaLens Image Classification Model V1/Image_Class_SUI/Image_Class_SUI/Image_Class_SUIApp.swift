//
//  Image_Class_SUIApp.swift
//  Image_Class_SUI
//
//  Created by Bill Skrzypczak on 6/2/24.
//

import SwiftUI

@main
struct Image_Class_SUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
